#include "hello.h"

int main(void) {
    print_hello();
    exit(0);
}